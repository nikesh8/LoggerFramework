//
//  LoggerFramework.h
//  LoggerFramework
//
//  Created by lw-66 on 11/10/22.
//

#import <Foundation/Foundation.h>

//! Project version number for LoggerFramework.
FOUNDATION_EXPORT double LoggerFrameworkVersionNumber;

//! Project version string for LoggerFramework.
FOUNDATION_EXPORT const unsigned char LoggerFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LoggerFramework/PublicHeader.h>


